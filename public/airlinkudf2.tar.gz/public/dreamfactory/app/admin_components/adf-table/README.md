adf-table
=========

AngularJS DreamFactory table component
